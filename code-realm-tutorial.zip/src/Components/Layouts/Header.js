import React from "react";

export default Header => (
  <div>
    <h1> Header</h1>
  </div>
);
