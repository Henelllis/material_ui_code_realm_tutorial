import React from "react";

export default Footer => (
  <div>
    <h1> Footer</h1>
  </div>
);
