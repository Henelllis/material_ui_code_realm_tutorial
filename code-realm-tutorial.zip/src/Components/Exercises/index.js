import React from "react";

export default props => <div>Hello from Henry Ellsi</div>;
