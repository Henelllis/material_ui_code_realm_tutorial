import React from "react";
import ReactDOM from "react-dom";
import App from "./Components/App";
const dummy = "dummy";
ReactDOM.render(<App />, document.getElementById("root"));
